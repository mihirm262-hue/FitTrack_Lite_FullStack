import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // Forward /api calls to the Spring Boot backend during local development
    proxy: { "/api": { target: "http://localhost:8080", changeOrigin: true } },
  },
});
